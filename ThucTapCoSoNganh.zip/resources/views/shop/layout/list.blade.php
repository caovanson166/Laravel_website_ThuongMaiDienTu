 <div class="featured__phone grid wide">
    <!-- Title -->
    <div class="row featured__phone__gutter">
        <div class="c-3">
            <div class="featured__phone__title">
                <a href="" class="featured__phone__title__text">Điện thoại nổi bật nhất</a>
            </div>
        </div>
        <div class="c-7">
            <div class="featured__phone__related__tag">
                <a href="" class="futured__phone__item">Apple</a>
            </div>
            <div class="featured__phone__related__tag">
                <a href="" class="futured__phone__item">Samsung</a>
            </div>
            <div class="featured__phone__related__tag">
                <a href="" class="futured__phone__item">Xiaomi</a>
            </div>
            <div class="featured__phone__related__tag">
                <a href="" class="futured__phone__item">OPPO</a>
            </div>
            <div class="featured__phone__related__tag">
                <a href="" class="futured__phone__item">Nokia</a>
            </div>
            <div class="featured__phone__related__tag">
                <a href="" class="futured__phone__item">Realme</a>
            </div>
            <div class="featured__phone__related__tag">
                <a href="" class="futured__phone__item">Vsmart</a>
            </div>
            <div class="featured__phone__related__tag">
                <a href="" class="futured__phone__item">ASUS</a>
            </div>
            <div class="featured__phone__related__tag">
                <a href="" class="futured__phone__item">Vivo</a>
            </div>
            <div class="featured__phone__related__tag">
                <a href="" class="futured__phone__item">Xem tất cả</a>
            </div>
        </div>
    </div>
    <!-- Tablet -->
    <div class="tablet__featured__phone">
        <div class="tablet__featured__phone__title">
            <a href="">Điện thoại nổi bật</a>
            <a href="">Xem tất cả</a>
        </div>
        <div class="tablet__featured__phone__tag__list">
            <div class="tablet__featured__phone__tag__item">
                <a href="">Apple</a>
            </div>
            <div class="tablet__featured__phone__tag__item">
                <a href="">Samsung</a>
            </div>
            <div class="tablet__featured__phone__tag__item">
                <a href="">Xiaomi</a>
            </div>
            <div class="tablet__featured__phone__tag__item">
                <a href="">OPPO</a>
            </div>
            <div class="tablet__featured__phone__tag__item">
                <a href="">Nokia</a>
            </div>
            <div class="tablet__featured__phone__tag__item">
                <a href="">Realme</a>
            </div>
            <div class="tablet__featured__phone__tag__item">
                <a href="">Vsmart</a>
            </div>
            <div class="tablet__featured__phone__tag__item">
                <a href="">Asus</a>
            </div>
            <div class="tablet__featured__phone__tag__item">
                <a href="">Vivo</a>
            </div>
            <div class="tablet__featured__phone__tag__item">
                <a href="">Vivo</a>
            </div>
            <div class="tablet__featured__phone__tag__item">
                <a href="">Vivo</a>
            </div>
            <div class="tablet__featured__phone__tag__item">
                <a href="">Vivo</a>
            </div>
            <div class="tablet__featured__phone__tag__item">
                <a href="">Vivo</a>
            </div>
        </div>
    </div>
    <!-- Product List -->
    <div class="featured__phone__product__list">
        <!-- 1st -->
@php
$p=0;
@endphp
        @foreach ($data as $d)
        @foreach ($d as $value)
        @php
$p++;
@endphp
        <div class="featured__phone__product__item">
            <!--  Discount -->
            <form action="" method="post">
                @if ($value->sale != 0)
                <div class="flash__sale__discount">
                    <p>Giảm {{ $value->sale }}%</p>
                </div>
                @endif
                @if ($value->sale >= 15)
                <div class="hot__sale">
                    <img src="{{ asset('shop/assets/img/Featured phone/hot sale.png') }}" alt="">
                </div>
                @endif
                <div class="featured__phone__product__img__wrapper">
                    <a href="{{route('pro',['file'=>$value->file,'name'=>$value->name_file])}}">
                        <img src="{{ asset('assets/upload/' . $value->main_img) }}"
                        alt="{{ $value->name }}">
                    </a>
                </div>
                <div class="featured__phone__product__desc">
                    <div class="featured__phone__product__desc__title">
                        <a href="{{route('pro',['file'=>$value->file,'name'=>$value->name_file])}}" class="featured__phone__product">
                            {{ $value->name }}
                        </a>
                    </div>
                    <div class="featured__phone__product__desc__price">
                        <div class="featured__phone__product__desc__price__new">
                            <p>
                                {{ $value->sale_product }}
                                <span class="featured__phone__product__desc__price__unit__new">đ</span>
                            </p>
                        </div>
                        <div class="featured__phone__product__desc__price__old">
                            <p>
                                {{ $value->price }}
                                <span class="featured__phone__product__desc__price__unit__old">đ</span>
                            </p>
                        </div>
                    </div>
                    @if ($value->hot != '' || !empty($value->hot))
                    <div class="featured__phone__product__promotion__info">
                        <p>{{ $value->hot }}</p>
                    </div>
                    @endif
                    <div class="featured__phone__product__desc__rare featured__phone__rare">
                        <div class="featured__phone__product__desc__rare__star">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="featured__phone__product__desc__rare__vote">
                            <p>&nbsp;9 đánh giá</p>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        @endforeach
        @endforeach
@if($p==0)
<div style="text-align: center;color: #F50F0F;font-size: 24px;">Chưa có sản phẩm nào thuộc doanh mục bạn đang chọn</div>
@endif


        <!-- More -->
        <div class="featured__phone__product__item view__all">
            <i class="fas fa-arrow-circle-right"></i>
            <p>More</p>
        </div>
    </div>
    <a class="btn-show-more btn-load-more cta-xem-san-pham" onclick="button.methods.loadMoreProduct(3, 3);">Xem
        thêm 453 sản phẩm  <i class="fas fa-chevron-down"></i></a>

        <!--  -->
        <div class="block-information__box-left">
            <div class="block-blog-content">
                <div class="blog-content__box-content">
                    <div class="blog-content" style="height: 400px;">
                        <p style="text-align: center;"><a class="btn btn-default"
                            href="https://cellphones.com.vn/mobile/apple/iphone-13.html">iPhone 13</a>&nbsp;<a
                            class="btn btn-default"
                            href="https://cellphones.com.vn/mobile/apple/iphone-12-vna.html">iPhone
                        12</a>&nbsp;<a class="btn btn-default"
                        href="https://cellphones.com.vn/samsung-galaxy-z-fold-3.html">Samsung Galaxy Z Fold
                    3</a>&nbsp;<a class="btn btn-default"
                    href="https://cellphones.com.vn/samsung-galaxy-s22-ultra.html">Samsung Galaxy S22
                Ultra</a></p>
                <h2 style="text-align: justify;">Điện thoại di động – Vật “bất li thân” ở thời đại công nghệ
                </h2>
                <p style="text-align: justify;">Khi khoa học kỹ thuật liên tục được cải tiến và công nghệ
                    phát
                    triển không ngừng thì đó cũng là lúc chiếc điện thoại di động trở nên quan trọng hơn bao
                    giờ
                    hết. Thật vậy, chúng ta có thể làm được rất nhiều việc: gọi điện, nhắn tin, gửi mail,
                    soạn
                    tài liệu (Word, Excel), chụp ảnh – quay video, xem phim hay chơi game với thiết bị có
                    kích
                thước chỉ bằng một bàn tay.</p>
                <p style="margin-top: 10px; margin-bottom: 10px; text-align: justify; line-height: 18px;">
                    Chính
                    vì vậy, thị trường di động&nbsp;luôn chứng kiến sự cạnh tranh vô cùng khốc liệt giữa các
                    nhà
                    sản xuất. Họ sẵn sàng đầu tư nghiên cứu để liên tục cho ra đời những chiếc <a
                    href="https://cellphones.com.vn/mobile/hang-sap-ve.html" target="_blank">điện thoại
                    mới
                nhất</a> chất lượng, từ giá rẻ, tầm trung, cận cao cấp cho đến cao cấp để đáp ứng
                tối đa
            nhu cầu của mọi đối tượng người dùng.</p>
            <h2 style="text-align: justify;"><strong>Có mấy loại điện thoại di động?</strong></h2>
            <p style="text-align: justify;">Xét về mục đích sử dụng, và thiết kế thì điện thoại di động
                sẽ
            được chia làm 4 loại chính.</p>
            <h3 style="text-align: justify;"><strong>Điện thoại thông minh</strong></h3>
            <p style="text-align: justify;">Điện thoại thông minh hay là smartphone, những mẫu điện
                thoại
                này được trang bị nhiều tính năng tân tiến về các điện toán và khả năng kết nối. Ngoài
                tính
                năng nghe – gọi cơ bản thì loại điện thoại này còn nhiều tính năng hiện đại khác như đọc
            báo, chơi game, lướt web và lên mạng xã hội.</p>
            <p style="text-align: justify;">Những điện thoại thuộc phân khúc này thường sở hữu màn hình
                lớn,
                camera độ phân giải cao và trang bị nhiều tính năng sinh trắc học như mở khóa gương mặt,
                vân
            tay,..</p>
            <p style="text-align: center;"><img class=" cpslazy" alt="Điện thoại thông minh"
                data-src="https://cdn.cellphones.com.vn/media/wysiwyg/mobile/dien-thoai-1.jpg"
                data-ll-status="observed"></p>
                <h3 style="text-align: justify;"><strong>Điện thoại phổ thông</strong></h3>
                <p style="text-align: justify;">Điện thoại phổ thông là những mẫu điện thoại tập trung vào
                    các
                    chức năng nghe – gọi là chính. Do đó mẫu điện thoại này sở hữu thiết kế vô cùng nhỏ gọn
                    với
                    hệ thống phím bấm lớn và viên pin sử dụng lâu ngày. Một số hiện thoại phổ thông ngày nay
                cũng được trang bị khả năng kết nối mạng, lên mạng xã hội.</p>
                <h3 style="text-align: justify;"><strong>Điện thoại chơi game</strong></h3>
                <p style="text-align: justify;">Điện thoại chơi game là một điện thoại thông minh nhưng được
                    thiết kế tối ưu hơn cho việc chơi game như tần số quét màn hình lớn, cấu hình máy khủng
                    cùng
                    hệ thống tản nhiệt được nâng cấp. Ngoài ra, điện thoại chơi game thường được hãng trang
                    bị
                    thêm các phụ kiện hỗ trợ quá trình chơi game hiệu quả hơn như tản nhiệt, tay cầm chơi
                    game.
                </p>
                <p style="text-align: center;"><img class=" cpslazy" alt="Điện thoại chơi game"
                    data-src="https://cdn.cellphones.com.vn/media/wysiwyg/mobile/dien-thoai-3.jpg"
                    data-ll-status="observed"></p>
                    <h3 style="text-align: justify;"><strong>Điện thoại chụp ảnh</strong></h3>
                    <p style="text-align: justify;">Tương tự điện thoại chơi game, điện thoại chụp ảnh là một
                        điện
                        thoại thông minh với phần camera được tối ưu. Hầu hết các điện thoại thông minh ngày nay
                        đều
                        được trang bị hệ thống camera chất lượng với khả năng chụp góc rộng, lấy nét quang học,
                        chụp
                    thiếu sáng,.. và chúng đều có thể là một chiếc điện thoại chụp ảnh chất lượng.</p>
                    <h2 style="text-align: justify;">Tại sao nên mua điện thoại thông minh?</h2>
                    <p><span style="text-align: justify;">-&nbsp; &nbsp;Được trang bị nhiều công nghệ hiện
                    đại</span><span style="text-align: justify;">.</span></p>
                    <p><span style="text-align: justify;"><span>-&nbsp; &nbsp;</span>Hỗ trợ tốt cho việc liên
                        lạc,
                    làm việc lẫn giải trí.</span></p>
                    <p><span style="text-align: justify;"></span><span
                        style="text-align: justify;"><span>-&nbsp;
                        &nbsp;</span>Không chỉ là thiết bị di động mà còn có thể đóng vai trò như một
                        món đồ
                    trang sức.</span></p>
                    <p><span style="text-align: justify;"></span><span
                        style="text-align: justify;"><span>-&nbsp;
                        &nbsp;</span>Dễ dàng kết nối với cộng đồng và thế giới.</span></p>
                        <p><span style="text-align: justify;"></span><span
                            style="text-align: justify;"><span>-&nbsp;
                            &nbsp;</span>Khả năng lưu giữ những khoảnh khắc đáng nhớ trong cuộc sống theo
                            nhiều
                        hình thức.</span></p>
                        <h2 style="text-align: justify;"><strong>Phân loại điện thoại smartphone theo tầm
                        giá</strong>
                    </h2>
                    <p style="text-align: justify;">Dựa vào giá bán, ta có thể chia điện thoại thông minh làm 4
                        loại
                    chính như sau:</p>
                    <h3 style="text-align: justify;"><strong>Điện thoại giá rẻ</strong></h3>
                    <p style="text-align: justify;"><strong></strong><em>-&nbsp; Thông tin chung</em>: Là những
                        thiết bị được bán với mức giá bình dân, phù hợp với đối tượng người dùng có điều kiện
                        tài
                    chính hạn chế.</p>
                    <p style="text-align: justify;"><em>-&nbsp; Đặc điểm</em>: Cấu hình tuy không mạnh mẽ nhưng
                        vẫn
                        đáp ứng tốt những nhu cầu hàng ngày (RAM 2 – 3 GB, chip Qualcomm 4xx hoặc Mediatek
                        6xxx), có
                        thể được phát hành với nhiều phiên bản màu sắc thời trang, kích thước nhỏ gọn mang lại
                        trải
                    nghiệm cầm nắm dễ chịu…</p>
                    <p style="text-align: justify;"><em>-&nbsp; Thương hiệu tiêu biểu</em>: Xiaomi Redmi Note 10
                        Pro
                    hay&nbsp;điện thoại Realme 8&nbsp;vừa ra mắt.</p>
                    <p style="text-align: center;"><img class=" cpslazy" alt="Smartphone giá rẻ"
                        data-src="https://cdn.cellphones.com.vn/media/wysiwyg/mobile/dien-thoai-11.jpg"
                        data-ll-status="observed"></p>
                        <h3 style="text-align: justify;"><strong>Điện thoại tầm trung</strong></h3>
                        <p><em>-&nbsp; Thông tin chung</em>: Bước nâng cấp so với dòng smartphone giá rẻ, có ngoại
                            hình
                        bắt mắt hơn và được nâng cấp về một số yếu tố.</p>
                        <p><em>-&nbsp; Đặc điểm</em>: Thiết kế kim loại sang trọng, màn hình lớn, viền mỏng có độ
                            phân
                            giải Full HD, tích hợp chip Snapdragon đời 6xx hoặc Helio P, RAM 3 – 4 GB cho hiệu suất
                            giải
                            trí tốt hơn. Ngoài ra, chúng còn sở hữu camera kép có khả năng chụp ảnh xóa phông, cảm
                            biến
                        vân tay, công nghệ mở khóa bằng gương mặt hay hỗ trợ cả AI (trí tuệ nhân tạo)...</p>
                        <p><em>-&nbsp; Sản phẩm tiêu biểu</em>: Samsung Galaxy A52 hay&nbsp;Xiaomi Mi 11 Lite
                        5G&nbsp;đang được bán độc quyền tại CellphoneS.</p>
                        <p style="text-align: center;"><img class=" cpslazy" alt="Smartphone tầm trung"
                            data-src="https://cdn.cellphones.com.vn/media/wysiwyg/mobile/dien-thoai-12.jpg"
                            data-ll-status="observed"></p>
                            <h3 style="text-align: justify;"><strong>Điện thoại cận cao cấp</strong></h3>
                            <p style="text-align: justify;"><em>-&nbsp; Thông tin chung</em>: Những sản phẩm nằm ở trên
                                phân
                            khúc tầm trung, được trang bị những thông số và công nghệ rất gần với nhóm cao cấp.</p>
                            <p style="text-align: justify;"><em>-&nbsp; Đặc điểm</em>: Thiết kế quyến rũ với kim loại +
                                kính, sử dụng chip Snapdragon 6xx tiên tiến hơn dòng smartphone tầm trung, RAM từ 4 – 6
                                GB,
                                màn hình Full HD tràn viền kích thước lớn, tích hợp tiêu chuẩn chống nước, được trang bị
                                viên pin dung lượng lớn cùng công nghệ sạc nhanh, camera kép độ phân giải cao đi kèm
                                nhiều
                            tính năng hữu ích…</p>
                            <p style="text-align: justify;"><em>-&nbsp; Thương hiệu tiêu biểu</em>: Samsung Galaxy A…
                            </p>
                            <h3 style="text-align: justify;"><strong>Điện thoại cao cấp</strong></h3>
                            <p style="text-align: justify;"><em>-&nbsp; Thông tin chung</em>: Những smartphone thuộc
                                nhóm
                                này đều có vẻ ngoài tuyệt đẹp, được trang bị phần cứng cực mạnh, phiên bản phần mềm mới
                                nhất
                            và nhiều công nghệ, tính năng hiện đại.</p>
                            <p style="text-align: justify;"><em>-&nbsp; Đặc điểm</em>: Hoàn thiện tinh xảo từ chất liệu
                                kim
                                loại, kính và có thể là cả gốm, màn hình tràn cạnh độ phân giải 2K, màn hình cong về 2
                                cạnh
                                bên, tích hợp chip Snapdragon đời mới nhất (8xx) hay Apple A-series, có khả năng chống
                                nước,
                                cảm biến nhận diện gương mặt 3D, camera kép hỗ trợ zoom quang học, tạo biểu tượng cảm
                                xúc
                            bằng chính gương mặt người dùng…</p>
                            <p style="text-align: justify;"><em>-&nbsp; Sản phẩm tiêu biểu:&nbsp;</em>Xiaomi Mi 11 5G,
                            Samsung Galaxy S21 Ultra 5G,&nbsp;iPhone 12...</p>
                            <p style="text-align: center;"><img class=" cpslazy" alt="Smartphone cao cấp"
                                data-src="https://cdn.cellphones.com.vn/media/wysiwyg/mobile/dien-thoai-13.jpg"
                                data-ll-status="observed"></p>
                                <h2 style="text-align: justify;"><strong>Các tiêu chí để lựa chọn điện thoại giá rẻ chất
                                lượng</strong></h2>
                                <p style="text-align: justify;">Có rất nhiều yếu tố khác nhau để quyết định một mẫu
                                    smartphone
                                có phải tốt nhất hay không. Hãy cùng điểm nhanh qua một số tiêu chí sau đây:</p>
                                <h3 style="text-align: justify;"><strong>Thiết kế</strong></h3>
                                <p style="text-align: justify;">Thiết kế bên ngoài ảnh hưởng rất lớn đến quyết định chọn mua
                                    của
                                    người dùng. Vì ngày nay, các sản phẩm điện thoại không chỉ đơn thuần là một thiết bị
                                    liên
                                    lạc, giải trí mà nó còn đóng vai trò là một phụ kiện trang trí, thể hiện phần nào tính
                                    cách
                                    của người dùng. Đây cũng là một lý do khiến các mẫu smartphone ngày càng trở nên mỏng
                                    hơn,
                                    nhiều màu sắc hơn. Hay thiết kế pin rời kém sang đã biến mất, thay vào đó là pin liền
                                    nguyên
                                khối sang trọng.</p>
                                <h3 style="text-align: justify;"><strong>Màn hình</strong></h3>
                                <p style="text-align: justify;">Kích thước màn hình cũng sẽ ảnh hưởng đến tiêu chí chọn mua
                                    của
                                    người tiêu dùng. Bởi một số người dùng thiết thích bị nhỏ gọn nhưng số khác lại yêu
                                    thích
                                    các thiết bị màn hình lớn. Ngày nay các mẫu điện thoại mới ra mắt đang sở hữu kích thước
                                    màn
                                    hình ngày càng lớn do đa phần người dùng thích những chiếc điện thoại có màn hình càng
                                    lớn
                                càng tốt.</p>
                                <p style="text-align: center;"><img class=" cpslazy" alt="Màn hình"
                                    data-src="https://cdn.cellphones.com.vn/media/wysiwyg/mobile/dien-thoai-5.jpg"
                                    data-ll-status="observed"></p>
                                    <h3 style="text-align: justify;"><strong>Hệ điều hành</strong></h3>
                                    <p style="text-align: justify;">Sẽ có nhiều người dùng lựa chọn hệ điều hành đầu tiên trước
                                        khi
                                        chọn mua mẫu điện thoại nào đó. Hiện nay một số hệ điều hành có trên điện thoại di động
                                        phải
                                        kể đến như iOS, Android, BlackBerry OS hay Windows Phone. Mỗi hệ điều hành sẽ được xây
                                        dựng
                                        và phát triển trên các nền tảng khác nhau nên sẽ có những ưu và nhược điểm khác nhau.
                                    </p>
                                    <p style="text-align: justify;">- <strong>Hệ điều hành Android:</strong></p>
                                    <p style="text-align: justify;">Đây là hệ điều hành mở được Google phát triển trên nền tảng
                                        Linux và là hệ điều hành được sử dụng phổ biến nhất. Do được sử dụng phổ biến bởi nhiều
                                        thương hiệu nên các thiết bị chạy hệ điều hành Android cũng sở hữu mức giá khá đa dạng,
                                        từ
                                        điện thoại giá rẻ, tầm trung, cận cao cấp đến cao cấp bạn đều có thể tìm được sản phẩm
                                        chạy
                                    trên hệ điều hành này.</p>
                                    <p style="text-align: justify;">Ngoài ra, do là hệ điều hành mở nên người dùng có thể tùy
                                        biến
                                        giao diện một cách dễ dàng theo sở thích cá nhân. Nhưng đây cũng là một điểm yếu của hệ
                                        điều
                                    hành Android này khi độ an toàn, tính bảo mật chưa cao.</p>
                                    <p style="text-align: center;"><img class=" cpslazy" alt="Hệ điều hành"
                                        data-src="https://cdn.cellphones.com.vn/media/wysiwyg/mobile/dien-thoai-6.jpg"
                                        data-ll-status="observed"></p>
                                        <p style="text-align: justify;">- <strong>Hệ điều hành iOS:</strong></p>
                                        <p style="text-align: justify;">iOS là hệ điều hành với tính bảo mật cao do được phát triển
                                            trên
                                            một nền tảng đóng. Mỗi một phiên bản iOS đều được kiểm thử rất kỹ càng trước khi đưa ra
                                            thị
                                        trường. Nếu phát hiện lỗ hổng mới sẽ được update nhanh chóng.</p>
                                        <p style="text-align: justify;">Nhược điểm của hệ điều hành là người dùng sẽ không được tùy
                                            biến
                                        giao diện, bàn phím theo phong cách của bản thân.</p>
                                        <p style="text-align: justify;">- <strong>Hệ điều hành BlackBerry OS</strong></p>
                                        <p style="text-align: justify;">Hệ điều hành BlackBerry OS có tính bảo mật cao dùng giao
                                            diện sử
                                        dụng bắt mắt. Tuy nhiên kho ứng dụng trên hệ điều hành này chưa thực sự phong phú.</p>
                                        <h3 style="text-align: justify;"><strong>Cấu hình</strong></h3>
                                        <p style="text-align: justify;">Con chip CPU + GPU sẽ quyết định đến tốc độ đa nhiệm và hoạt
                                            động của máy. Dung lượng RAM càng lớn, khả năng đa nhiệm của máy càng mượt. Và hầu hết
                                            các
                                            sản phẩm điện thoại hiện nay đều được trang bị dung lượng ram từ 3GB trở nên. Với các
                                            dòng
                                        sản phẩm cao cấp, có thể lên đến 6-8GB RAM.</p>
                                        <h3 style="text-align: justify;"><strong>Bộ nhớ trong</strong></h3>
                                        <p style="text-align: justify;">Bộ nhớ là không gian lưu trữ hình ảnh, ứng dụng. Do đó người
                                            dùng sẽ ưu tiên một thiết bị sở hữu dung lượng bộ nhớ lớn hoặc có hỗ trợ thẻ nhớ mở
                                            rộng.
                                            Ngày nay, hầu hết các thiết bị smartphone đều sở hữu dung lượng bộ nhớ trong lớn tủ
                                            64GB.
                                        </p>
                                        <h3 style="text-align: justify;"><strong>Camera</strong></h3>
                                        <p style="text-align: justify;">Nếu người dùng yêu thích quay phim, chụp ảnh hoặc sử dụng
                                            điện
                                            thoại phục vụ công việc tương tự thì camera là nhân tố rất quan trọng. Lúc này, ngoài
                                            thông
                                            số camera thì còn sẽ quan tâm nhiều tính năng khác như hỗ trợ chụp ảnh góc rộng, khả
                                            năng
                                        lấy nét,...</p>
                                        <p style="text-align: center;"><img class=" cpslazy" alt="Camera"
                                            data-src="https://cdn.cellphones.com.vn/media/wysiwyg/mobile/dien-thoai-7.jpg"
                                            data-ll-status="observed"></p>
                                            <h3 style="text-align: justify;"><strong>Dung lượng pin</strong></h3>
                                            <p style="text-align: justify;">Một điện thoại pin càng lớn, càng được người dùng yêu thích.
                                                Vì
                                                chỉ số dung lượng càng lớn (mAH) đồng nghĩa điện thoại có thể sử dụng càng lâu. Ngoài
                                                ra,
                                                người dùng sẽ còn quan tâm đến tính năng sạc nhanh của máy để lựa chọn sản phẩm khi mua.
                                            </p>
                                            <h3 style="text-align: justify;"><strong>Tính năng đặc biệt</strong></h3>
                                            <p style="text-align: justify;">Ngoài những thông số trên thì quyết định tiêu dùng của điện
                                                thoại còn ảnh hưởng bởi một số tính năng đặc biệt của sản phẩm. Như một số điện thoại sẽ
                                                hỗ
                                            trợ vân tay mặt lưng, như số khác sẽ trang bị vân tay trong màn hình.</p>
                                            <h3 style="text-align: justify;"><strong>Giá thành</strong></h3>
                                            <p style="text-align: justify;">Giá bán là một trong những yếu tố quan trọng nhất để quyết
                                                định
                                                người dùng có chọn mua một sản phẩm nào đó hay không. Với mỗi người dùng sẽ có những
                                                phân
                                            khúc lựa chọn khác nhau:</p>
                                            <p style="text-align: justify;">-&nbsp; Học sinh, sinh viên: Đối tượng này đặc điểm là khả
                                                năng
                                                tài chính còn phụ thuộc gia đình do đó sản phẩm hướng tới đa số là điện thoại phân khúc
                                                giá
                                            rẻ 3-4 triệu đồng.</p>
                                            <p style="text-align: justify;">-&nbsp; Nhân viên văn phòng, công – nhân viên chức: Đây là
                                                nhóm
                                                người dùng đã có khả năng tự chủ tài chính nên tiêu chí chọn mua smartphone cũng cao hơn
                                                như
                                                thiết kế đẹp, camera chụp tốt,... và các sản phẩm chọn mua đa số thuộc phân khúc cận cao
                                            cấp: từ 8 – 10 triệu đồng.</p>
                                            <p style="text-align: justify;">-&nbsp; Tín đồ công nghệ: Đây là phân khúc người yêu công
                                                nghệ,
                                            thường mong muốn sở hữu một mẫu điện thoại mạnh nhất, tốt nhất.</p>
                                            <h2 style="text-align: justify;"><strong>TOP 5 hãng điện thoại bán chạy nhất hiện
                                            nay</strong>
                                        </h2>
                                        <p style="text-align: justify;">Thị trường smartphone khá nhộn nhịp với nhiều sản phẩm đến
                                            từ
                                            nhiều thương hiệu khác nhau. Nhưng bán chạy nhất trên thị trường là 5 thương hiệu
                                            smartphone
                                        sau:</p>
                                        <h3 style="text-align: justify;"><strong>Apple</strong></h3>
                                        <p style="text-align: justify;">Điện thoại iPhone với hầu hết sản phẩm nằm trong phân khúc
                                            cao
                                            cấp, do đó sản phẩm điện thoại iPhone với hiệu năng mạnh. Năm 2020, Apple đứng thứ 3 thế
                                        giới (chiếm tới 14% thị phần) với hơn 36 triệu thiết bị bán ra.</p>
                                        <p style="text-align: justify;">Một số sản phẩm nổi bật: iPhone 11, iPhone 12, iPhone Xr,...
                                        </p>
                                        <p style="text-align: center;"><img class=" cpslazy" alt="Apple"
                                            data-src="https://cdn.cellphones.com.vn/media/wysiwyg/mobile/dien-thoai-8.jpg"
                                            data-ll-status="observed"></p>
                                            <h3 style="text-align: justify;"><strong>Samsung</strong></h3>
                                            <p style="text-align: justify;">Là mẫu điện thoại bán chạy thứ 2 thế giới trong năm 2020,
                                                Samsung chiếm tới 20% thị trường smartphone khi bán ra hơn 54 triệu máy. Các sản phẩm
                                                điện
                                                thoại Samsung khá đa dạng phân khúc từ flagship cao cấp (dòng Samsung S, Samsung Note),
                                                tầm
                                            trung (Samsung A) và một số sản phẩm phân khúc giá rẻ khác.</p>
                                            <p style="text-align: justify;">Một số sản phẩm nổi bật: Samsung Note 20, Samsung S21,
                                                Samsung
                                            A52,...</p>
                                            <p style="text-align: center;"><img class=" cpslazy" alt="Samsung"
                                                data-src="https://cdn.cellphones.com.vn/media/wysiwyg/mobile/dien-thoai-9.jpg"
                                                data-ll-status="observed"></p>
                                                <h3 style="text-align: justify;"><strong>Xiaomi</strong></h3>
                                                <p style="text-align: justify;">Xiaomi là thương hiệu điện thoại Trung Quốc, hãng điện thoại
                                                    này
                                                    chiếm tới 10% thị phần điện thoại di động trên toàn thế giới với hơn 26 triệu máy bán ra
                                                    trong năm 2020 và dừng chân ở vị trí thứ 4 trong 5 thương hiệu smartphone bán chạy toàn
                                                    cầu.
                                                </p>
                                                <p style="text-align: justify;">Các sản phẩm Xiaomi nổi bật với dung lượng pin siêu cao,
                                                    hiệu
                                                    năng khủng. Một số sản phẩm nổi bật như: Xiaomi Mi 11 Lite 5G, Xiaomi Redmi Note 10,
                                                    Xiaomi
                                                Mi 10T Pro,..</p>
                                                <h3 style="text-align: justify;"><strong>Oppo</strong></h3>
                                                <p style="text-align: justify;">Là thương hiệu đứng thứ 5 trong danh sách, điện thoại OPPO
                                                    có
                                                    doanh số bán lên đến hơn 24 triệu máy, chiếm 9% thị phần. Các sản phẩm điện thoại OPPO
                                                    với
                                                thiết kế sang trọng, camera chất lượng cùng giá bán phải chăng.</p>
                                                <p style="text-align: justify;">Một số điện thoại OPPO nổi bật: OPPO Reno5, OPPO A93, OPPO
                                                    A15,…
                                                </p>
                                                <p style="text-align: center;"><img class=" cpslazy" alt="Oppo"
                                                    data-src="https://cdn.cellphones.com.vn/media/wysiwyg/mobile/dien-thoai-10.jpg"
                                                    data-ll-status="observed"></p>
                                                    <h3 style="text-align: justify;"><strong>Realme</strong></h3>
                                                    <p style="text-align: justify;">Điện thoại Realme đang có sự tăng trưởng vượt bậc trong
                                                        những
                                                        năm gần đây. Sản phẩm điện thoại Realme tập trung chủ yếu ở phân khúc giá rẻ và tầm
                                                        trung.
                                                    </p>
                                                    <p style="text-align: justify;">Một số sản phẩm nổi bật: Realme 6, Realme 8 Pro, Realme
                                                        C15,…
                                                    </p>
                                                    <h2 style="text-align: justify;">Mua smartphone giá rẻ tại cửa hàng điện thoại CellphoneS
                                                    </h2>
                                                    <ul style="text-align: justify;">
                                                        <li
                                                        style="line-height: 18px; list-style-type: circle; margin-bottom: 8px; margin-left: 30px;">
                                                        <p>Tại hệ thống cửa hàng điện thoại&nbsp;<a href="https://cellphones.com.vn/"
                                                            target="_blank">CellphoneS</a> tất cả các sản phẩm đều có xuất xứ rõ ràng và
                                                            hóa
                                                        đơn đầy đủ</p>
                                                    </li>
                                                    <li
                                                    style="line-height: 18px; list-style-type: circle; margin-bottom: 8px; margin-left: 30px;">
                                                    <p>Bảo hành chính hãng 12 tháng, 1 đổi 1 trong 30 ngày đầu tiên</p>
                                                </li>
                                                <li
                                                style="line-height: 18px; list-style-type: circle; margin-bottom: 8px; margin-left: 30px;">
                                                <p>Giá <span>bán hấp dẫn trên thị trường</span>. Nhiều chương trình khuyến mãi hấp
                                                    dẫn.
                                                Chương trình thu cũ đổi mới, lên đời điện thoại</p>
                                            </li>
                                            <li
                                            style="line-height: 18px; list-style-type: circle; margin-bottom: 8px; margin-left: 30px;">
                                            <p>Nhiều dịch vụ tiện ích: trả góp 0% qua thẻ tính dụng với hơn 20 ngân hàng. Thanh
                                                toán
                                                online, thanh toán bằng thẻ, giao hàng và thu tiền tại nhà miễn phí trên toàn
                                                quốc.
                                            </p>
                                        </li>
                                        <li
                                        style="line-height: 18px; list-style-type: circle; margin-bottom: 8px; margin-left: 30px;">
                                        <p>Đội ngũ nhân viên tư vấn offline và chăm sóc khách hàng online luôn sẵn sàng giải
                                            đáp
                                        mọi thắc mắc, đáp ứng tối đa nhu cầu của người dùng.</p>
                                    </li>
                                    <li
                                    style="line-height: 18px; list-style-type: circle; margin-bottom: 8px; margin-left: 30px;">
                                    <p>Ngoài ra, CellphoneS còn kinh doanh các dòng <a
                                        href="https://cellphones.com.vn/tablet.html">máy tính bảng giá rẻ</a> cho
                                        đến
                                    cao cấp&nbsp;với mức giá hấp dẫn nhất thị trường.</p>
                                </li>
                            </ul>
                            <div style="float: left; width: 23.5%; text-align: justify; margin-left: 2%;"></div>
                        </div>
                        <div class="box-btn-show-more"><a class="btn-show-more cta-xem-them-bai-viet">Xem thêm <i
                            class="fas fa-chevron-down"></i></a></div>
                        </div>
                    </div>

                    <div id="moduleComment" data-pagetype="2" data-pageurl="https://cellphones.com.vn/mobile.html"
                    class="block-comment" style="display: block;">
                    <div class="block-comment__box-title">
                        <p id="total_comment" class="totalcomment">Hỏi và đáp</p>
                    </div>
                    <div class="block-comment__box-form-comment form-add"><textarea id="review_field" name="detail"
                        rows="4" cols="5"
                        placeholder="Xin mời để lại câu hỏi, CellphoneS sẽ trả lời ngay trong 1h, các câu hỏi sau 22h - 8h sẽ được trả lời vào sáng hôm sau."
                        class="cps-textarea"></textarea> <a href="javascript:void(0)" id="btnSendCmt"
                        class="btn-send-cmt cta-cate-gui-binh-luan"><i class="fas fa-paper-plane"></i>&nbsp;Gửi</a>
                        <span id="sub-comment-error" class="comment-error error-text error d-none">Vui lòng nhập bình
                        luận</span>
                    </div>
                    <div class="block-comment__box-list-comment">
                        <div data-index="1" data-load="0" data-count="" id="product_comment_list" class="list-comment">
                            <div class="item-comment">
                                <div class="item-comment__box-cmt">
                                    <div class="box-cmt__box-info">
                                        <div class="box-info">
                                            <div class="box-info__avatar">N</div>
                                            <p class="box-info__name">Nguyễn Công Thành</p>
                                            <!---->
                                        </div>
                                        <p class="box-time-cmt"><svg xmlns="http://www.w3.org/2000/svg" width="12"
                                            height="12" viewBox="0 0 12 12">
                                            <path id="clock"
                                            d="M7.72,8.78,5.25,6.31V3h1.5v2.69L8.78,7.72ZM6,0a6,6,0,1,0,6,6A6,6,0,0,0,6,0ZM6,10.5A4.5,4.5,0,1,1,10.5,6,4.5,4.5,0,0,1,6,10.5Z"
                                            fill="#707070"></path>
                                        </svg>&nbsp;5 tiếng trước</p>
                                    </div>
                                    <div class="box-cmt__box-question">
                                        <p>
                                            Bao giờ redmi note 11 pro 5G về VN thế ạ?
                                        </p> <a href="javascript:void(0)" class="btn-rep-cmt respondent"><svg
                                            xmlns="http://www.w3.org/2000/svg" width="13" height="12"
                                            viewBox="0 0 12 10.8">
                                            <path id="chat"
                                            d="M3.48,8.32V4.6H1.2A1.2,1.2,0,0,0,0,5.8V9.4a1.2,1.2,0,0,0,1.2,1.2h.6v1.8l1.8-1.8h3A1.2,1.2,0,0,0,7.8,9.4V8.308a.574.574,0,0,1-.12.013H3.48ZM10.8,1.6H5.4A1.2,1.2,0,0,0,4.2,2.8V7.6H8.4l1.8,1.8V7.6h.6A1.2,1.2,0,0,0,12,6.4V2.8a1.2,1.2,0,0,0-1.2-1.2Z"
                                            transform="translate(0 -1.6)" fill="#707070"></path>
                                        </svg>&nbsp;Trả lời
                                    </a>
                                </div>
                                <div class="item-comment__box-rep-comment">
                                    <div class="list-rep-comment">
                                        <div class="item-rep-comment">
                                            <div class="box-cmt__box-info">
                                                <div class="box-info">
                                                    <div class="box-info__avatar"><i class="cps-icons icon-cps"></i>
                                                    </div>
                                                    <p class="box-info__name">Quản trị viên</p> <span
                                                    class="box-info__tag">QTV</span>
                                                </div>
                                                <p class="box-time-cmt"><svg xmlns="http://www.w3.org/2000/svg"
                                                    width="12" height="12" viewBox="0 0 12 12">
                                                    <path id="clock"
                                                    d="M7.72,8.78,5.25,6.31V3h1.5v2.69L8.78,7.72ZM6,0a6,6,0,1,0,6,6A6,6,0,0,0,6,0ZM6,10.5A4.5,4.5,0,1,1,10.5,6,4.5,4.5,0,0,1,6,10.5Z"
                                                    fill="#707070"></path>
                                                </svg>&nbsp;1 tiếng trước</p>
                                            </div>
                                            <div class="box-cmt__box-question">
                                                <p>
                                                    CellphoneS xin chào Anh Thành
                                                </p>
                                                <p>
                                                    Dạ rất tiếc hiện tại CellphoneS chưa có lịch về hàng sản phẩm
                                                    này.
                                                    Mình quan tâm sản phẩm này em xin phép lưu thông tin, khi nào có
                                                    hàng CellphoneS sẽ chủ động liên hệ thông báo cho mình ạ.
                                                </p>
                                                <p>

                                                </p>
                                                <p>
                                                    Thân mến.
                                                </p>
                                                <p>

                                                </p> <a href="javascript:void(0)"
                                                class="btn-rep-cmt respondent"><svg
                                                xmlns="http://www.w3.org/2000/svg" width="13" height="12"
                                                viewBox="0 0 12 10.8">
                                                <path id="chat"
                                                d="M3.48,8.32V4.6H1.2A1.2,1.2,0,0,0,0,5.8V9.4a1.2,1.2,0,0,0,1.2,1.2h.6v1.8l1.8-1.8h3A1.2,1.2,0,0,0,7.8,9.4V8.308a.574.574,0,0,1-.12.013H3.48ZM10.8,1.6H5.4A1.2,1.2,0,0,0,4.2,2.8V7.6H8.4l1.8,1.8V7.6h.6A1.2,1.2,0,0,0,12,6.4V2.8a1.2,1.2,0,0,0-1.2-1.2Z"
                                                transform="translate(0 -1.6)" fill="#707070"></path>
                                            </svg>&nbsp;Trả lời
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!---->
                    </div>
                </div>
                <div class="item-comment">
                    <div class="item-comment__box-cmt">
                        <div class="box-cmt__box-info">
                            <div class="box-info">
                                <div class="box-info__avatar">m</div>
                                <p class="box-info__name">mi</p>
                                <!---->
                            </div>
                            <p class="box-time-cmt"><svg xmlns="http://www.w3.org/2000/svg" width="12"
                                height="12" viewBox="0 0 12 12">
                                <path id="clock"
                                d="M7.72,8.78,5.25,6.31V3h1.5v2.69L8.78,7.72ZM6,0a6,6,0,1,0,6,6A6,6,0,0,0,6,0ZM6,10.5A4.5,4.5,0,1,1,10.5,6,4.5,4.5,0,0,1,6,10.5Z"
                                fill="#707070"></path>
                            </svg>&nbsp;14 tiếng trước</p>
                        </div>
                        <div class="box-cmt__box-question">
                            <p>
                                cho em hỏi iphone 11 và 11 pro 99% giá bao nhiêu v ạ
                            </p> <a href="javascript:void(0)" class="btn-rep-cmt respondent"><svg
                                xmlns="http://www.w3.org/2000/svg" width="13" height="12"
                                viewBox="0 0 12 10.8">
                                <path id="chat"
                                d="M3.48,8.32V4.6H1.2A1.2,1.2,0,0,0,0,5.8V9.4a1.2,1.2,0,0,0,1.2,1.2h.6v1.8l1.8-1.8h3A1.2,1.2,0,0,0,7.8,9.4V8.308a.574.574,0,0,1-.12.013H3.48ZM10.8,1.6H5.4A1.2,1.2,0,0,0,4.2,2.8V7.6H8.4l1.8,1.8V7.6h.6A1.2,1.2,0,0,0,12,6.4V2.8a1.2,1.2,0,0,0-1.2-1.2Z"
                                transform="translate(0 -1.6)" fill="#707070"></path>
                            </svg>&nbsp;Trả lời
                        </a>
                    </div>
                    <div class="item-comment__box-rep-comment">
                        <div class="list-rep-comment">
                            <div class="item-rep-comment">
                                <div class="box-cmt__box-info">
                                    <div class="box-info">
                                        <div class="box-info__avatar"><i class="cps-icons icon-cps"></i>
                                        </div>
                                        <p class="box-info__name">Quản trị viên</p> <span
                                        class="box-info__tag">QTV</span>
                                    </div>
                                    <p class="box-time-cmt"><svg xmlns="http://www.w3.org/2000/svg"
                                        width="12" height="12" viewBox="0 0 12 12">
                                        <path id="clock"
                                        d="M7.72,8.78,5.25,6.31V3h1.5v2.69L8.78,7.72ZM6,0a6,6,0,1,0,6,6A6,6,0,0,0,6,0ZM6,10.5A4.5,4.5,0,1,1,10.5,6,4.5,4.5,0,0,1,6,10.5Z"
                                        fill="#707070"></path>
                                    </svg>&nbsp;14 tiếng trước</p>
                                </div>
                                <div class="box-cmt__box-question">
                                    <p>
                                        CellphoneS xin chào chị Mi
                                    </p>
                                    <p>
                                        sản phẩm APPLE IPHONE 11 64GB TÍM CŨ - ĐẸP giá thời điểm hiện
                                        tại
                                        11.290.000 (HCM)
                                    </p>
                                    <p>
                                        APPLE IPHONE 11 PRO 64GB XANH CŨ - ĐẸP giá thời điểm hiện tại
                                        14.990.000 (HCM)
                                    </p>
                                    <p>
                                        Chi tiết hơn, em xin phép liên hệ trao đổi trực tiếp cho mình
                                        qua
                                        SĐT
                                    </p>
                                    <p>
                                        Xin thông tin đến Chị
                                    </p>
                                    <p>

                                    </p> <a href="javascript:void(0)"
                                    class="btn-rep-cmt respondent"><svg
                                    xmlns="http://www.w3.org/2000/svg" width="13" height="12"
                                    viewBox="0 0 12 10.8">
                                    <path id="chat"
                                    d="M3.48,8.32V4.6H1.2A1.2,1.2,0,0,0,0,5.8V9.4a1.2,1.2,0,0,0,1.2,1.2h.6v1.8l1.8-1.8h3A1.2,1.2,0,0,0,7.8,9.4V8.308a.574.574,0,0,1-.12.013H3.48ZM10.8,1.6H5.4A1.2,1.2,0,0,0,4.2,2.8V7.6H8.4l1.8,1.8V7.6h.6A1.2,1.2,0,0,0,12,6.4V2.8a1.2,1.2,0,0,0-1.2-1.2Z"
                                    transform="translate(0 -1.6)" fill="#707070"></path>
                                </svg>&nbsp;Trả lời
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!---->
        </div>
    </div>
    <div class="item-comment">
        <div class="item-comment__box-cmt">
            <div class="box-cmt__box-info">
                <div class="box-info">
                    <div class="box-info__avatar">Đ</div>
                    <p class="box-info__name">Đặng Khánh Nam</p>
                    <!---->
                </div>
                <p class="box-time-cmt"><svg xmlns="http://www.w3.org/2000/svg" width="12"
                    height="12" viewBox="0 0 12 12">
                    <path id="clock"
                    d="M7.72,8.78,5.25,6.31V3h1.5v2.69L8.78,7.72ZM6,0a6,6,0,1,0,6,6A6,6,0,0,0,6,0ZM6,10.5A4.5,4.5,0,1,1,10.5,6,4.5,4.5,0,0,1,6,10.5Z"
                    fill="#707070"></path>
                </svg>&nbsp;17 tiếng trước</p>
            </div>
            <div class="box-cmt__box-question">
                <p>
                    Oppo 73 có thu lại không ạ
                </p> <a href="javascript:void(0)" class="btn-rep-cmt respondent"><svg
                    xmlns="http://www.w3.org/2000/svg" width="13" height="12"
                    viewBox="0 0 12 10.8">
                    <path id="chat"
                    d="M3.48,8.32V4.6H1.2A1.2,1.2,0,0,0,0,5.8V9.4a1.2,1.2,0,0,0,1.2,1.2h.6v1.8l1.8-1.8h3A1.2,1.2,0,0,0,7.8,9.4V8.308a.574.574,0,0,1-.12.013H3.48ZM10.8,1.6H5.4A1.2,1.2,0,0,0,4.2,2.8V7.6H8.4l1.8,1.8V7.6h.6A1.2,1.2,0,0,0,12,6.4V2.8a1.2,1.2,0,0,0-1.2-1.2Z"
                    transform="translate(0 -1.6)" fill="#707070"></path>
                </svg>&nbsp;Trả lời
            </a>
        </div>
        <div class="item-comment__box-rep-comment">
            <div class="list-rep-comment">
                <div class="item-rep-comment">
                    <div class="box-cmt__box-info">
                        <div class="box-info">
                            <div class="box-info__avatar"><i class="cps-icons icon-cps"></i>
                            </div>
                            <p class="box-info__name">Quản trị viên</p> <span
                            class="box-info__tag">QTV</span>
                        </div>
                        <p class="box-time-cmt"><svg xmlns="http://www.w3.org/2000/svg"
                            width="12" height="12" viewBox="0 0 12 12">
                            <path id="clock"
                            d="M7.72,8.78,5.25,6.31V3h1.5v2.69L8.78,7.72ZM6,0a6,6,0,1,0,6,6A6,6,0,0,0,6,0ZM6,10.5A4.5,4.5,0,1,1,10.5,6,4.5,4.5,0,0,1,6,10.5Z"
                            fill="#707070"></path>
                        </svg>&nbsp;17 tiếng trước</p>
                    </div>
                    <div class="box-cmt__box-question">
                        <p>
                            CellphoneS xin chào anh Đặng Khánh Nam,
                        </p>
                        <p>
                            Dạ trường hợp máy của mình là OPPO A73 6GB 128GB có ngoại hình
                            và
                            màn đẹp, máy đầy đủ chức năng và phụ kiện CellphoneS sẽ thu lại
                            với
                            mức giá 2.700.000đ ( giá tham khảo). Chính xác hơn mình vui lòng
                            mang máy đến cửa hàng để kỹ thuật viên thẩm định và hỗ trợ ạ.
                        </p>
                        <p>
                            Thân mến.
                        </p>
                        <p>

                        </p> <a href="javascript:void(0)"
                        class="btn-rep-cmt respondent"><svg
                        xmlns="http://www.w3.org/2000/svg" width="13" height="12"
                        viewBox="0 0 12 10.8">
                        <path id="chat"
                        d="M3.48,8.32V4.6H1.2A1.2,1.2,0,0,0,0,5.8V9.4a1.2,1.2,0,0,0,1.2,1.2h.6v1.8l1.8-1.8h3A1.2,1.2,0,0,0,7.8,9.4V8.308a.574.574,0,0,1-.12.013H3.48ZM10.8,1.6H5.4A1.2,1.2,0,0,0,4.2,2.8V7.6H8.4l1.8,1.8V7.6h.6A1.2,1.2,0,0,0,12,6.4V2.8a1.2,1.2,0,0,0-1.2-1.2Z"
                        transform="translate(0 -1.6)" fill="#707070"></path>
                    </svg>&nbsp;Trả lời
                </a>
            </div>
        </div>
    </div>
</div>
<!---->
</div>
</div>
<div class="item-comment">
    <div class="item-comment__box-cmt">
        <div class="box-cmt__box-info">
            <div class="box-info">
                <div class="box-info__avatar">V</div>
                <p class="box-info__name">Vũ</p>
                <!---->
            </div>
            <p class="box-time-cmt"><svg xmlns="http://www.w3.org/2000/svg" width="12"
                height="12" viewBox="0 0 12 12">
                <path id="clock"
                d="M7.72,8.78,5.25,6.31V3h1.5v2.69L8.78,7.72ZM6,0a6,6,0,1,0,6,6A6,6,0,0,0,6,0ZM6,10.5A4.5,4.5,0,1,1,10.5,6,4.5,4.5,0,0,1,6,10.5Z"
                fill="#707070"></path>
            </svg>&nbsp;19 tiếng trước</p>
        </div>
        <div class="box-cmt__box-question">
            <p>
                Có k30 5g k ạ và giá ạ
            </p> <a href="javascript:void(0)" class="btn-rep-cmt respondent"><svg
                xmlns="http://www.w3.org/2000/svg" width="13" height="12"
                viewBox="0 0 12 10.8">
                <path id="chat"
                d="M3.48,8.32V4.6H1.2A1.2,1.2,0,0,0,0,5.8V9.4a1.2,1.2,0,0,0,1.2,1.2h.6v1.8l1.8-1.8h3A1.2,1.2,0,0,0,7.8,9.4V8.308a.574.574,0,0,1-.12.013H3.48ZM10.8,1.6H5.4A1.2,1.2,0,0,0,4.2,2.8V7.6H8.4l1.8,1.8V7.6h.6A1.2,1.2,0,0,0,12,6.4V2.8a1.2,1.2,0,0,0-1.2-1.2Z"
                transform="translate(0 -1.6)" fill="#707070"></path>
            </svg>&nbsp;Trả lời
        </a>
    </div>
    <div class="item-comment__box-rep-comment">
        <div class="list-rep-comment">
            <div class="item-rep-comment">
                <div class="box-cmt__box-info">
                    <div class="box-info">
                        <div class="box-info__avatar"><i class="cps-icons icon-cps"></i>
                        </div>
                        <p class="box-info__name">Quản trị viên</p> <span
                        class="box-info__tag">QTV</span>
                    </div>
                    <p class="box-time-cmt"><svg xmlns="http://www.w3.org/2000/svg"
                        width="12" height="12" viewBox="0 0 12 12">
                        <path id="clock"
                        d="M7.72,8.78,5.25,6.31V3h1.5v2.69L8.78,7.72ZM6,0a6,6,0,1,0,6,6A6,6,0,0,0,6,0ZM6,10.5A4.5,4.5,0,1,1,10.5,6,4.5,4.5,0,0,1,6,10.5Z"
                        fill="#707070"></path>
                    </svg>&nbsp;19 tiếng trước</p>
                </div>
                <div class="box-cmt__box-question">
                    <p>
                        CellphoneS xin chào anh Vũ
                    </p>
                    <p>
                        Dạ em vẫn chưa có hàng nên chưa có giá báo anh ạ. Em xin được
                        giữ
                        thông tin của anh để khi có hàng sẽ liên hệ ạ.
                    </p>
                    <p>
                        Em cám ơn Anh đã quan tâm đến CellphoneS ạ.
                    </p>
                    <p>

                    </p> <a href="javascript:void(0)"
                    class="btn-rep-cmt respondent"><svg
                    xmlns="http://www.w3.org/2000/svg" width="13" height="12"
                    viewBox="0 0 12 10.8">
                    <path id="chat"
                    d="M3.48,8.32V4.6H1.2A1.2,1.2,0,0,0,0,5.8V9.4a1.2,1.2,0,0,0,1.2,1.2h.6v1.8l1.8-1.8h3A1.2,1.2,0,0,0,7.8,9.4V8.308a.574.574,0,0,1-.12.013H3.48ZM10.8,1.6H5.4A1.2,1.2,0,0,0,4.2,2.8V7.6H8.4l1.8,1.8V7.6h.6A1.2,1.2,0,0,0,12,6.4V2.8a1.2,1.2,0,0,0-1.2-1.2Z"
                    transform="translate(0 -1.6)" fill="#707070"></path>
                </svg>&nbsp;Trả lời
            </a>
        </div>
    </div>
</div>
</div>
<!---->
</div>
</div>
<div class="item-comment">
    <div class="item-comment__box-cmt">
        <div class="box-cmt__box-info">
            <div class="box-info">
                <div class="box-info__avatar">A</div>
                <p class="box-info__name">An Phương</p>
                <!---->
            </div>
            <p class="box-time-cmt"><svg xmlns="http://www.w3.org/2000/svg" width="12"
                height="12" viewBox="0 0 12 12">
                <path id="clock"
                d="M7.72,8.78,5.25,6.31V3h1.5v2.69L8.78,7.72ZM6,0a6,6,0,1,0,6,6A6,6,0,0,0,6,0ZM6,10.5A4.5,4.5,0,1,1,10.5,6,4.5,4.5,0,0,1,6,10.5Z"
                fill="#707070"></path>
            </svg>&nbsp;1 ngày trước</p>
        </div>
        <div class="box-cmt__box-question">
            <p>
                iphone 8plus có giá bn vậy ạ
            </p> <a href="javascript:void(0)" class="btn-rep-cmt respondent"><svg
                xmlns="http://www.w3.org/2000/svg" width="13" height="12"
                viewBox="0 0 12 10.8">
                <path id="chat"
                d="M3.48,8.32V4.6H1.2A1.2,1.2,0,0,0,0,5.8V9.4a1.2,1.2,0,0,0,1.2,1.2h.6v1.8l1.8-1.8h3A1.2,1.2,0,0,0,7.8,9.4V8.308a.574.574,0,0,1-.12.013H3.48ZM10.8,1.6H5.4A1.2,1.2,0,0,0,4.2,2.8V7.6H8.4l1.8,1.8V7.6h.6A1.2,1.2,0,0,0,12,6.4V2.8a1.2,1.2,0,0,0-1.2-1.2Z"
                transform="translate(0 -1.6)" fill="#707070"></path>
            </svg>&nbsp;Trả lời
        </a>
    </div>
    <div class="item-comment__box-rep-comment">
        <div class="list-rep-comment">
            <div class="item-rep-comment">
                <div class="box-cmt__box-info">
                    <div class="box-info">
                        <div class="box-info__avatar"><i class="cps-icons icon-cps"></i>
                        </div>
                        <p class="box-info__name">Quản trị viên</p> <span
                        class="box-info__tag">QTV</span>
                    </div>
                    <p class="box-time-cmt"><svg xmlns="http://www.w3.org/2000/svg"
                        width="12" height="12" viewBox="0 0 12 12">
                        <path id="clock"
                        d="M7.72,8.78,5.25,6.31V3h1.5v2.69L8.78,7.72ZM6,0a6,6,0,1,0,6,6A6,6,0,0,0,6,0ZM6,10.5A4.5,4.5,0,1,1,10.5,6,4.5,4.5,0,0,1,6,10.5Z"
                        fill="#707070"></path>
                    </svg>&nbsp;1 ngày trước</p>
                </div>
                <div class="box-cmt__box-question">
                    <p>
                        CellphoneS xin chào chị An Phương,
                    </p>
                    <p>
                        Dạ APPLE IPHONE 8 PLUS 256GB BẠC CŨ - ĐẸP giá ở thời điểm hiện
                        tại
                        là 9.200.000 sẵn hàng tại 133 Thái Hà, P. Trung Liệt, Q, Đống Đa
                        .
                        Không biết khi nào chị có thể đến được cửa hàng để em giữ hàng +
                        giá
                        hiện tại trong vòng 24h cho mình tiện đi lại ạ.
                    </p>
                    <p>
                        Mong phản hồi sớm từ chị.
                    </p>
                    <p>

                    </p> <a href="javascript:void(0)"
                    class="btn-rep-cmt respondent"><svg
                    xmlns="http://www.w3.org/2000/svg" width="13" height="12"
                    viewBox="0 0 12 10.8">
                    <path id="chat"
                    d="M3.48,8.32V4.6H1.2A1.2,1.2,0,0,0,0,5.8V9.4a1.2,1.2,0,0,0,1.2,1.2h.6v1.8l1.8-1.8h3A1.2,1.2,0,0,0,7.8,9.4V8.308a.574.574,0,0,1-.12.013H3.48ZM10.8,1.6H5.4A1.2,1.2,0,0,0,4.2,2.8V7.6H8.4l1.8,1.8V7.6h.6A1.2,1.2,0,0,0,12,6.4V2.8a1.2,1.2,0,0,0-1.2-1.2Z"
                    transform="translate(0 -1.6)" fill="#707070"></path>
                </svg>&nbsp;Trả lời
            </a>
        </div>
    </div>
</div>
</div>
<!---->
</div>
</div>
</div> <a id="cmt_loadmore" href="javascript:void(0)" class="btn-show-more" style="">Xem thêm <i
    class="fas fa-chevron-down"></i></a>
</div>
<div id="comment-module-modal" tabindex="-1" role="dialog" aria-labelledby="popup_cmt_form"
aria-hidden="true" class="modal fade cps-popup">
<div role="document" class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title">Thông tin người gửi</h4> <button type="button"
            data-dismiss="modal" class="close"><svg xmlns="http://www.w3.org/2000/svg"
            width="12" height="12" viewBox="0 0 12 12">
            <path id="cross"
            d="M11.89,9.64h0L8.249,6l3.64-3.64h0a.376.376,0,0,0,0-.53L10.17.109a.376.376,0,0,0-.53,0h0L6,3.749,2.359.109h0a.376.376,0,0,0-.53,0L.109,1.829a.376.376,0,0,0,0,.53h0L3.75,6,.109,9.64h0a.38.38,0,0,0-.086.134.374.374,0,0,0,.086.4l1.72,1.72a.376.376,0,0,0,.53,0h0L6,8.249l3.64,3.64h0a.376.376,0,0,0,.53,0l1.72-1.72a.376.376,0,0,0,0-.53Z"
            transform="translate(0 0)" fill="#fff"></path>
        </svg>&nbsp;Đóng</button>
    </div>
    <div class="modal-body">
        <form method="post" id="commentForm" class="popup_cmt_form"><input name="form_key"
            type="hidden" value="pvGPOC4ANS6OJFBg"> <input type="text" name="nickname"
            id="nickname_field" value="" placeholder="Họ tên (bắt buộc)"
            class="cps-input required-entry">
            <div class="error-text-comment-info error-text error d-none">
                Quý khách vui lòng kiểm tra lại thông tin
            </div> <input type="text" name="phone" id="phone_field" value=""
            placeholder="Số điện thoại" class="cps-input">
            <div class="error-text-comment-info error-text error d-none">
                Quý khách vui lòng kiểm tra lại thông tin
            </div> <input type="text" name="email" id="email_field" value=""
            placeholder="Email (để nhận phản hồi qua email)" class="cps-input">
            <!---->
            <div data-sitekey="6LetVbYUAAAAABRM1I3VO6WD-xxhzTKiR9MDmbNK"
            class="g-recaptcha mb-3" style="display: none;">
            <div style="width: 304px; height: 78px;">
                <div><iframe title="reCAPTCHA"
                    src="https://www.google.com/recaptcha/api2/anchor?ar=2&amp;k=6LetVbYUAAAAABRM1I3VO6WD-xxhzTKiR9MDmbNK&amp;co=aHR0cHM6Ly9jZWxscGhvbmVzLmNvbS52bjo0NDM.&amp;hl=vi&amp;v=1p3YWy80wlZ7Q8QFR1gjazwU&amp;size=normal&amp;cb=lvjkqky8kxcz"
                    width="304" height="78" role="presentation" name="a-c9hq7o8s84v"
                    frameborder="0" scrolling="no"
                    sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe>
                </div><textarea id="g-recaptcha-response" name="g-recaptcha-response"
                class="g-recaptcha-response"
                style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea>
            </div><iframe style="display: none;"></iframe>
        </div> <button id="cps_comment_post" type="submit" title="Gửi bình luận"
        class="button"><b>Gửi bình luận</b></button>
    </form>
</div>
</div>
</div>
</div>
</div>

</div>
</div>
