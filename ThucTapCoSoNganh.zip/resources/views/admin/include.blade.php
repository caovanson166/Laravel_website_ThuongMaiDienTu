

@extends('extends.admin')

@section('title')
    <title>Dashboard - Admin</title>
@endsection

@section('meta')

@endsection

@section('content')


@endsection
