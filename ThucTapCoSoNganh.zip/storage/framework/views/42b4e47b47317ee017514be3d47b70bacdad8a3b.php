<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->yieldContent('title'); ?>
    <?php echo $__env->yieldContent('meta'); ?>
</head>
<body>
<div class="main" id="main">
    <?php echo $__env->make('shop.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->yieldContent('content'); ?>
    
    <?php echo $__env->make('shop.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('script'); ?>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ThucTapCoSoNganh\resources\views/extends/shop1.blade.php ENDPATH**/ ?>